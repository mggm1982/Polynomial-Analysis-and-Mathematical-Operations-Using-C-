#include <iostream>
using namespace std;

const int MAX_DEGREE = 20;

// Function to input the coefficients of a polynomial
void inputPolynomial(int coefficients[], int degree, char name) {
    cout << "\nEnter coefficients for " << name << "(x):\n";

    for (int i = 0; i <= degree; i++) {
        if (i == 0) {
            cout << "Constant term: ";
        }
        else {
            cout << "Coefficient of x^" << i << ": ";
        }

        while (!(cin >> coefficients[i])) {
            cout << "Invalid input. Enter an integer: ";
            cin.clear();
            cin.ignore(10000, '\n');
        }
    }
}

// Function to display a polynomial
void displayPolynomial(int coefficients[], int degree) {
    bool firstTerm = true;

    for (int i = degree; i >= 0; i--) {
        int value = coefficients[i];

        if (value == 0) {
            continue;
        }

        if (!firstTerm) {
            if (value > 0) {
                cout << " + ";
            }
            else {
                cout << " - ";
            }
        }
        else if (value < 0) {
            cout << "-";
        }

        if (value < 0) {
            value = -value;
        }

        if (i == 0 || value != 1) {
            cout << value;
        }

        if (i > 0) {
            cout << "x";
        }

        if (i > 1) {
            cout << "^" << i;
        }

        firstTerm = false;
    }

    if (firstTerm) {
        cout << "0";
    }

    cout << endl;
}

// Function to find the actual degree of a polynomial
int findDegree(int coefficients[], int degree) {
    for (int i = degree; i >= 0; i--) {
        if (coefficients[i] != 0) {
            return i;
        }
    }

    return 0;
}

// Function to add two polynomials
void addPolynomials(int p[], int degreeP, int q[], int degreeQ, int result[]) {
    int largestDegree;

    if (degreeP > degreeQ) {
        largestDegree = degreeP;
    }
    else {
        largestDegree = degreeQ;
    }

    for (int i = 0; i <= largestDegree; i++) {
        int a = 0;
        int b = 0;

        if (i <= degreeP) {
            a = p[i];
        }

        if (i <= degreeQ) {
            b = q[i];
        }

        result[i] = a + b;
    }
}

// Function to subtract Q(x) from P(x)
void subtractPolynomials(int p[], int degreeP, int q[], int degreeQ, int result[]) {
    int largestDegree;

    if (degreeP > degreeQ) {
        largestDegree = degreeP;
    }
    else {
        largestDegree = degreeQ;
    }

    for (int i = 0; i <= largestDegree; i++) {
        int a = 0;
        int b = 0;

        if (i <= degreeP) {
            a = p[i];
        }

        if (i <= degreeQ) {
            b = q[i];
        }

        result[i] = a - b;
    }
}

// Function to multiply two polynomials
void multiplyPolynomials(int p[], int degreeP, int q[], int degreeQ, int result[]) {
    int resultDegree = degreeP + degreeQ;

    for (int i = 0; i <= resultDegree; i++) {
        result[i] = 0;
    }

    for (int i = 0; i <= degreeP; i++) {
        for (int j = 0; j <= degreeQ; j++) {
            result[i + j] += p[i] * q[j];
        }
    }
}

// Function to evaluate a polynomial at a given value of x
int evaluatePolynomial(int coefficients[], int degree, int x) {
    int answer = 0;
    int power = 1;

    for (int i = 0; i <= degree; i++) {
        answer += coefficients[i] * power;
        power *= x;
    }

    return answer;
}

// Function to differentiate a polynomial
void differentiatePolynomial(int coefficients[], int degree, int result[]) {
    if (degree == 0) {
        result[0] = 0;
        return;
    }

    for (int i = 0; i < degree; i++) {
        result[i] = coefficients[i + 1] * (i + 1);
    }

    result[degree] = 0;
}

// Function to read and validate the degree
int readDegree(char name) {
    int degree;

    while (true) {
        cout << "Enter degree of " << name
             << "(x) (0 to " << MAX_DEGREE << "): ";

        if (cin >> degree && degree >= 0 && degree <= MAX_DEGREE) {
            return degree;
        }

        cout << "Invalid degree. Enter an integer from 0 to "
             << MAX_DEGREE << ".\n";

        cin.clear();
        cin.ignore(10000, '\n');
    }
}

// Function to display the menu
void displayMenu() {
    cout << "\n========== POLYNOMIAL OPERATIONS ==========\n";
    cout << "1. Display both polynomials\n";
    cout << "2. Add P(x) and Q(x)\n";
    cout << "3. Subtract Q(x) from P(x)\n";
    cout << "4. Multiply P(x) and Q(x)\n";
    cout << "5. Evaluate P(x)\n";
    cout << "6. Evaluate Q(x)\n";
    cout << "7. Differentiate P(x)\n";
    cout << "8. Differentiate Q(x)\n";
    cout << "9. Enter new polynomials\n";
    cout << "0. Exit\n";
    cout << "Choose an option: ";
}

int main() {
    int p[MAX_DEGREE + 1] = {0};
    int q[MAX_DEGREE + 1] = {0};
    int result[2 * MAX_DEGREE + 1] = {0};

    int degreeP, degreeQ;
    int choice = -1;

    cout << "============================================\n";
    cout << " Polynomial Analysis and Mathematical Ops\n";
    cout << "============================================\n";

    // Input polynomial P
    degreeP = readDegree('P');
    inputPolynomial(p, degreeP, 'P');

    // Input polynomial Q
    degreeQ = readDegree('Q');
    inputPolynomial(q, degreeQ, 'Q');

    degreeP = findDegree(p, degreeP);
    degreeQ = findDegree(q, degreeQ);

    // Display the entered polynomials
    cout << "\nYou entered:\n";

    cout << "P(x) = ";
    displayPolynomial(p, degreeP);

    cout << "Q(x) = ";
    displayPolynomial(q, degreeQ);

    // Display the menu until the user chooses to exit
    do {
        displayMenu();

        choice = -1;
        cin >> choice;

        if (cin.fail()) {
            cout << "Invalid input. Enter a menu number.\n";

            cin.clear();
            cin.ignore(10000, '\n');

            continue;
        }

        switch (choice) {
            case 1:
                cout << "P(x) = ";
                displayPolynomial(p, degreeP);

                cout << "Q(x) = ";
                displayPolynomial(q, degreeQ);
                break;

            case 2: {
                addPolynomials(p, degreeP, q, degreeQ, result);

                int d;

                if (degreeP > degreeQ) {
                    d = degreeP;
                }
                else {
                    d = degreeQ;
                }

                d = findDegree(result, d);

                cout << "P(x) + Q(x) = ";
                displayPolynomial(result, d);
                break;
            }

            case 3: {
                subtractPolynomials(p, degreeP, q, degreeQ, result);

                int d;

                if (degreeP > degreeQ) {
                    d = degreeP;
                }
                else {
                    d = degreeQ;
                }

                d = findDegree(result, d);

                cout << "P(x) - Q(x) = ";
                displayPolynomial(result, d);
                break;
            }

            case 4: {
                multiplyPolynomials(p, degreeP, q, degreeQ, result);

                int d = findDegree(result, degreeP + degreeQ);

                cout << "P(x) * Q(x) = ";
                displayPolynomial(result, d);
                break;
            }

            case 5:
            case 6: {
                int x;

                cout << "Enter the value of x: ";

                if (!(cin >> x)) {
                    cout << "Invalid input. Enter an integer.\n";

                    cin.clear();
                    cin.ignore(10000, '\n');

                    break;
                }

                if (choice == 5) {
                    cout << "P(" << x << ") = "
                         << evaluatePolynomial(p, degreeP, x)
                         << endl;
                }
                else {
                    cout << "Q(" << x << ") = "
                         << evaluatePolynomial(q, degreeQ, x)
                         << endl;
                }

                break;
            }

            case 7:
            case 8: {
                int d;

                if (choice == 7) {
                    differentiatePolynomial(p, degreeP, result);
                    d = degreeP;
                }
                else {
                    differentiatePolynomial(q, degreeQ, result);
                    d = degreeQ;
                }

                if (d > 0) {
                    d--;
                }
                else {
                    d = 0;
                }

                d = findDegree(result, d);

                if (choice == 7) {
                    cout << "P'(x) = ";
                }
                else {
                    cout << "Q'(x) = ";
                }

                displayPolynomial(result, d);
                break;
            }

            case 9: {
                // Clear the previous coefficients
                for (int i = 0; i <= MAX_DEGREE; i++) {
                    p[i] = 0;
                    q[i] = 0;
                }

                // Input the new polynomial P
                degreeP = readDegree('P');
                inputPolynomial(p, degreeP, 'P');

                // Input the new polynomial Q
                degreeQ = readDegree('Q');
                inputPolynomial(q, degreeQ, 'Q');

                degreeP = findDegree(p, degreeP);
                degreeQ = findDegree(q, degreeQ);

                cout << "\nUpdated polynomials:\n";

                cout << "P(x) = ";
                displayPolynomial(p, degreeP);

                cout << "Q(x) = ";
                displayPolynomial(q, degreeQ);
                break;
            }

            case 0:
                cout << "Thank you for using the program.\n";
                break;

            default:
                cout << "Invalid option. Choose from 0 to 9.\n";
        }

    } while (choice != 0);

    return 0;
}